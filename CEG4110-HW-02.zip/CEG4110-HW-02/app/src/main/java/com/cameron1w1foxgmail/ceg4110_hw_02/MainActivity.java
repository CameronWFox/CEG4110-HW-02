package com.cameron1w1foxgmail.ceg4110_hw_02;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.Time;
import android.view.View;
import android.widget.Button;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    Calendar calendar = Calendar.getInstance();

    ClockModel clockModel;
    ClockPanelController controller;

    DigitalClockView dcView;
    AnalogClockView acView;

    Time time;
    Handler handler;
    Runnable runnable;

    // Buttons for the Control Panel
    private Button add_year, add_month, add_day;
    private Button add_hour, add_minute, add_second;

    private Button sub_year, sub_month, sub_day;
    private Button sub_hour, sub_minute, sub_second;

    private Button undo_change;
    private Button redo_change;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        controller = new ClockPanelController(clockModel, acView, dcView);

        dcView = findViewById(R.id.digitalclock);
        acView = findViewById(R.id.analogclock);

        add_hour = findViewById(R.id.addHour);
        add_minute = findViewById(R.id.addMinute);
        add_second = findViewById(R.id.addSecond);
        add_year = findViewById(R.id.addYear);
        add_month = findViewById(R.id.addMonth);
        add_day = findViewById(R.id.addDay);

        sub_hour = findViewById(R.id.subHour);
        sub_minute = findViewById(R.id.subMinute);
        sub_second = findViewById(R.id.subSecond);
        sub_year = findViewById(R.id.subYear);
        sub_month = findViewById(R.id.subMonth);
        sub_day = findViewById(R.id.subDay);

        undo_change = findViewById(R.id.undo);
        redo_change = findViewById(R.id.redo);


        // Button OnClick for each choice
        add_hour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int addHour = calendar.get(Calendar.HOUR_OF_DAY) + 1;
                controller.updateClockView();

            }
        });
        add_minute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int addMinute = calendar.get(Calendar.MINUTE) + 1;
                controller.updateClockView();

            }
        });
        add_second.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int addSecond = calendar.get(Calendar.SECOND) + 1;
                controller.updateClockView();

            }
        });
        add_year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int addYear = calendar.get(Calendar.YEAR) + 1;
                controller.updateClockView();
            }
        });
        add_month.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int addMonth = calendar.get(Calendar.MONTH) + 1;
                controller.updateClockView();
            }
        });
        add_day.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int addDay = calendar.get(Calendar.DAY_OF_MONTH) + 1;
                controller.updateClockView();
            }
        });

        sub_hour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int subHour = calendar.get(Calendar.HOUR_OF_DAY) - 1;
                controller.updateClockView();

            }
        });
        sub_minute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int subMinute = calendar.get(Calendar.MINUTE) - 1;
                controller.updateClockView();

            }
        });
        sub_second.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int subSecond = calendar.get(Calendar.SECOND) - 1;
                controller.updateClockView();

            }
        });
        sub_year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int subYear = calendar.get(Calendar.YEAR) - 1;
                controller.updateClockView();

            }
        });
        sub_month.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int subMonth = calendar.get(Calendar.MONTH) - 1;
                controller.updateClockView();

            }
        });
        sub_day.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int subDay = calendar.get(Calendar.DAY_OF_MONTH) - 1;
                controller.updateClockView();

            }
        });

        // Clock Setup Section
        time = new Time();
        runnable = new Runnable() {
            @Override
            public void run() {
                time.setToNow();
                dcView = new DigitalClockView(MainActivity.this);

                acView = new AnalogClockView(MainActivity.this);

                handler.postDelayed(runnable, 1000);
            }
        };

        handler = new Handler();
        handler.postDelayed(runnable, 1000);
    }



}