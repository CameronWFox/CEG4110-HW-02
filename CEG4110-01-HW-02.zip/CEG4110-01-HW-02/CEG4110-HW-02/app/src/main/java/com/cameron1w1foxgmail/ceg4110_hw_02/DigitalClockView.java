package com.cameron1w1foxgmail.ceg4110_hw_02;

import android.content.Context;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.widget.TextView;

import java.util.Calendar;

public class DigitalClockView extends View {

    TextView clockTimeViewD;
    TextView clockDateViewD;

    public DigitalClockView(Context context){
        super(context);
    }

    public DigitalClockView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void newClockUpdates(int currentHour, int currentMinute, int currentSecond,
                                int currentYear, int currentMonth, int currentDay) {

        String newTimeText = String.format("%02d:%02d:%02d", currentHour, currentMinute, currentSecond);

        String newDateText = String.format("DATE: %d %d %d", currentMonth, currentDay, currentYear);

        clockTimeViewD.setText(newTimeText);
        clockDateViewD.setText(newDateText);

    }
}