package com.cameron1w1foxgmail.ceg4110_hw_02;

import java.util.Calendar;

public class ClockPanelController {

    Calendar calendar = Calendar.getInstance();

    ClockModel model;
    AnalogClockView analogView;
    DigitalClockView digitalView;

    private int currentHour = calendar.get(Calendar.HOUR_OF_DAY);
    private int currentMinute = calendar.get(Calendar.MINUTE);
    private int currentSecond = calendar.get(Calendar.SECOND);

    private int currentYear = calendar.get(Calendar.YEAR);
    private int currentMonth = calendar.get(Calendar.MONTH);
    private int currentDay = calendar.get(Calendar.DAY_OF_MONTH);

    public ClockPanelController(ClockModel model, AnalogClockView analogView,
                                DigitalClockView digitalView){
        this.model = model;
        this.analogView = analogView;
        this.digitalView = digitalView;
    }

    public int getCurrentHour(){
        return model.getCurrentHour();
    }
    public void setCurrentHour(int currentHour){
        model.setCurrentHour(currentHour);
    }

    public int getCurrentMinute(){
        return model.getCurrentMinute();
    }
    public void setCurrentMinute(int currentMinute){
        model.setCurrentMinute(currentMinute);
    }

    public int getCurrentSecond(){
        return model.getCurrentSecond();
    }
    public void setCurrentSecond(int currentSecond){
        model.setCurrentSecond(currentSecond);
    }

    public int getCurrentYear(){
        return model.getCurrentYear();
    }
    public void setCurrentYear(int currentYear){
        model.setCurrentYear(currentYear);
    }

    public int getCurrentMonth(){
        return model.getCurrentMonth();
    }
    public void setCurrentMonth(int currentMonth){
        model.setCurrentMonth(currentMonth);
    }

    public int getCurrentDay(){
        return model.getCurrentDay();
    }
    public void setCurrentDay(int currentDay){
        model.setCurrentDay(currentDay);
    }

    public void updateClockView(){
        analogView.newClockUpdates(currentHour, currentMinute,
                currentSecond, currentYear,
                currentMonth, currentDay);
        digitalView.newClockUpdates(currentHour, currentMinute,
                currentSecond, currentYear,
                currentMonth, currentDay);
    }
}
