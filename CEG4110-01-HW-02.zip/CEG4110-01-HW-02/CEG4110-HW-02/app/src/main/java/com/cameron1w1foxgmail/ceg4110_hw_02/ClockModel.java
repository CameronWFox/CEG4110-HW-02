package com.cameron1w1foxgmail.ceg4110_hw_02;

import android.graphics.ColorSpace;

import java.util.Calendar;

public class ClockModel {

    Calendar calendar = Calendar.getInstance();

    DigitalClockView dcView;
    AnalogClockView acView;

    private int currentHour = calendar.get(Calendar.HOUR_OF_DAY);
    private int currentMinute = calendar.get(Calendar.MINUTE);
    private int currentSecond = calendar.get(Calendar.SECOND);

    private int currentYear = calendar.get(Calendar.YEAR);
    private int currentMonth = calendar.get(Calendar.MONTH);
    private int currentDay = calendar.get(Calendar.DAY_OF_MONTH);

    public int getCurrentHour(){
        return currentHour;
    }
    public void setCurrentHour(int currentHour){
        this.currentHour = currentHour;
    }

    public int getCurrentMinute(){
        return currentMinute;
    }
    public void setCurrentMinute(int currentMinute){
        this.currentMinute = currentMinute;
    }

    public int getCurrentSecond(){
        return currentSecond;
    }
    public void setCurrentSecond(int currentSecond){
        this.currentSecond = currentSecond;
    }

    public int getCurrentYear(){
        return currentYear;
    }
    public void setCurrentYear(int currentYear){
        this.currentYear = currentYear;
    }

    public int getCurrentMonth(){
        return currentMonth;
    }
    public void setCurrentMonth(int currentMonth){
        this.currentMonth = currentMonth;
    }

    public int getCurrentDay(){
        return currentDay;
    }
    public void setCurrentDay(int currentDay){
        this.currentDay = currentDay;
    }
}
